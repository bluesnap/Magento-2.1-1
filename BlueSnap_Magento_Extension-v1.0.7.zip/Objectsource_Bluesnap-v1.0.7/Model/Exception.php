<?php
namespace Bluesnap\Payment\Model;

use Magento\Framework\Exception\LocalizedException;

class Exception extends LocalizedException
{

}
